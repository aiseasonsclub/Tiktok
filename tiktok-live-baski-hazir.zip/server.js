// TikTok LIVE olaylarını (yorum, hediye, takip, beğeni) tarayıcıya SSE ile iletir.
const express = require('express');
const path = require('path');
const { WebcastPushConnection } = require('tiktok-live-connector');

const app = express();
const PORT = process.env.PORT || 3000;
app.use(express.static(path.join(__dirname, 'public')));

const clients = new Set();
let conn = null;
let currentUser = null;

function broadcast(obj) {
  const line = `data: ${JSON.stringify(obj)}\n\n`;
  for (const res of clients) res.write(line);
}

app.get('/events', (req, res) => {
  res.set({
    'Content-Type': 'text/event-stream',
    'Cache-Control': 'no-cache',
    Connection: 'keep-alive',
    'X-Accel-Buffering': 'no',
  });
  res.flushHeaders();
  res.write('retry: 2000\n\n');
  clients.add(res);
  const ping = setInterval(() => res.write(': ping\n\n'), 20000);
  req.on('close', () => { clearInterval(ping); clients.delete(res); });
});

function connect(user) {
  user = String(user || '').replace('@', '').trim();
  if (!user) return;
  if (conn && currentUser === user) return;
  if (conn) { try { conn.disconnect(); } catch (e) {} }
  currentUser = user;
  conn = new WebcastPushConnection(user);

  const start = () => conn.connect()
    .then(() => broadcast({ type: 'status', text: `@${user} bağlandı` }))
    .catch((err) => {
      broadcast({ type: 'status', text: 'Bağlanamadı, tekrar denenecek (yayın açık mı?)' });
      console.error('connect error:', err.message || err);
      setTimeout(() => currentUser === user && start(), 8000);
    });

  conn.on('chat', (d) => broadcast({
    type: 'chat', user: d.uniqueId, name: d.nickname, avatar: d.profilePictureUrl, text: d.comment,
  }));
  conn.on('gift', (d) => {
    // Seri hediyelerde (gül vb.) sadece seri bittiğinde say
    if (d.giftType === 1 && !d.repeatEnd) return;
    const diamonds = (d.diamondCount || 0) * (d.repeatCount || 1);
    broadcast({
      type: 'gift', user: d.uniqueId, name: d.nickname, avatar: d.profilePictureUrl,
      gift: d.giftName, diamonds,
    });
  });
  conn.on('follow', (d) => broadcast({
    type: 'follow', user: d.uniqueId, name: d.nickname, avatar: d.profilePictureUrl,
  }));
  conn.on('like', (d) => broadcast({
    type: 'like', user: d.uniqueId, name: d.nickname, avatar: d.profilePictureUrl, count: d.likeCount,
  }));
  conn.on('disconnected', () => {
    broadcast({ type: 'status', text: 'Bağlantı koptu, yeniden deneniyor' });
    setTimeout(() => currentUser === user && start(), 5000);
  });
  start();
}

// Sayfa ?user=kullaniciadi ile açılınca bağlanır
app.get('/connect', (req, res) => { connect(req.query.user); res.json({ ok: true }); });

if (process.env.TIKTOK_USER) connect(process.env.TIKTOK_USER);

app.listen(PORT, () => console.log('Hazır: http://localhost:' + PORT));
