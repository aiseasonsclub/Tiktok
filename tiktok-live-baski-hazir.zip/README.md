# TikTok Live Baskı (Virtual Printer)

TikTok canlı yayınında izleyicilerin yorum ve hediyelerine göre profil fotoğraflarını sanal yazıcıda basan interaktif overlay.

- Yorumda **"ben"** yazanlar sıraya girer
- Hediye gönderenler öncelikli basılır (gül, çiçek, donut, elmas vs. farklı çerçeveler)
- Takip edenler de basılabilir

## Hızlı Başlangıç (Yerel)

```bash
# 1. Bağımlılıkları yükle
npm install

# 2. Çalıştır
npm start
```

Tarayıcıda aç: [http://localhost:3000](http://localhost:3000)

- Kullanıcı adını girip **Başlat**
- Veya **Demo** butonuyla test et

## GitHub'a Yükleme

1. GitHub'da yeni repo oluştur (örnek isim: `tiktok-live-baski`)
2. Aşağıdaki komutları çalıştır:

```bash
git init
git add .
git commit -m "İlk sürüm - TikTok Live Baskı"
git branch -M main
git remote add origin https://github.com/KULLANICI_ADIN/tiktok-live-baski.git
git push -u origin main
```

## Online Yayınlama (Önerilen - Railway)

Railway ücretsiz planıyla kolay deploy edilir ve sürekli çalışır.

1. [railway.app](https://railway.app) → GitHub ile giriş yap
2. **New Project** → **Deploy from GitHub repo** → bu repoyu seç
3. Deploy bitsin, **Settings → Networking → Generate Domain** tıkla
4. Gelen adresi kopyala (örnek: `https://tiktok-live-baski-production.up.railway.app`)

Artık bu adresi OBS / TikTok LIVE Studio / telefon ekran paylaşımında kullanabilirsin.

### Alternatif Hosting
- **Render.com** (Free Web Service)
- **Fly.io**
- **VPS** (DigitalOcean, Hetzner vs.)

> Not: Vercel / Netlify gibi pure serverless yerler bu proje için uygun değil (sürekli açık Node sunucusu gerekiyor).

## Kullanım (Yayında)

1. Overlay adresini aç: `https://senin-adresin.com/?user=tiktokkullaniciadin`
2. OBS'de Browser Source olarak ekle (genişlik 1080, yükseklik 1920 önerilir)
3. Veya telefonda **Mobile gaming** ile ekranı paylaş
4. Canlı yayını başlat

### Parametreler
| Parametre | Açıklama | Örnek |
|-----------|----------|-------|
| `user` | Otomatik bağlanacak TikTok kullanıcı adı | `?user=ahmetayhanw` |
| `kw` | Sıraya girmek için yazılması gereken kelime | `?kw=bana` (varsayılan: `ben`) |
| `demo` | Bağlanmadan demo modu | `?demo=1` |

## Hediye Seviyeleri (varsayılan)

- 🌹 Gül / düşük → Normal baskı
- 🏵️ Orta → Altın çerçeve
- 🍩 Yüksek → Tam sayfa
- 💎 Çok yüksek → Efsanevi

## Teknik

- Node.js 18+
- `tiktok-live-connector` → TikTok LIVE olaylarını dinler
- SSE (Server-Sent Events) → tarayıcıya anlık iletir
- Saf HTML/CSS/JS → ekstra build yok

## Lisans

Kişisel kullanım için serbest. Ticari kullanımdan önce TikTok kurallarını kontrol et.